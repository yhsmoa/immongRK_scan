const mongoose = require('mongoose');

const chinaImportSchema = new mongoose.Schema({
    shipmentCode: {
        type: String,
        required: true
    },
    pallet: {
        type: String,
        required: true
    },
    boxName: {
        type: String,
        required: true
    },
    orderNumber: {
        type: String
    },
    productName: {
        type: String,
        required: true
    },
    quantity: {
        type: Number,
        required: true
    },
    barcode: {
        type: String
    },
    availableOrders: {
        type: String
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('ChinaImport', chinaImportSchema); 